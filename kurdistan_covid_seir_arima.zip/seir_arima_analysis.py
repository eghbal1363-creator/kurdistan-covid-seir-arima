import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
import matplotlib.dates as mdates
from datetime import datetime, timedelta
import pandas as pd

# SEIR model function
def seir_model(state, t, beta, alpha, gamma, N):
    S, E, I, R = state
    dSdt = -beta * S * I / N
    dEdt = beta * S * I / N - alpha * E
    dIdt = alpha * E - gamma * I
    dRdt = gamma * I
    return [dSdt, dEdt, dIdt, dRdt]

# Parameters
N = 1_600_000
beta = 0.3
alpha = 0.2
gamma = 0.1
I0 = 100
E0 = 200
R0 = 0
S0 = N - I0 - E0 - R0
state0 = [S0, E0, I0, R0]
t = np.linspace(0, 60, 60)

# Solve SEIR ODE
solution = odeint(seir_model, state0, t, args=(beta, alpha, gamma, N))
S, E, I, R = solution.T

# Generate synthetic hospitalizations
dates = [datetime(2020, 2, 20) + timedelta(days=x) for x in range(60)]
hospitalizations = np.clip(50 * np.exp(-0.05 * t) * np.sin(0.3 * t + 1.5) + 50, 0, 100)

# Save synthetic data
df_hosp = pd.DataFrame({'Date': dates, 'Hospitalizations': hospitalizations})
df_hosp.to_csv('synthetic_hospitalizations.csv', index=False)

# Plot SEIR
plt.figure(figsize=(10,6))
plt.subplot(2,1,1)
plt.plot(t, S/N, label='Susceptible (S)', color='#1f77b4')
plt.plot(t, E/N, label='Exposed (E)', color='#ff7f0e')
plt.plot(t, I/N, label='Infected (I)', color='#2ca02c')
plt.plot(t, R/N, label='Recovered (R)', color='#d62728')
plt.xlabel('Days from Feb 20, 2020')
plt.ylabel('Population ratio')
plt.title('SEIR model of the COVID-19 epidemic in Kurdistan')
plt.legend()
plt.grid(True)

plt.subplot(2,1,2)
plt.plot(dates, hospitalizations, label='Daily hospitalizations', color='#9467bd')
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
plt.gca().xaxis.set_major_locator(mdates.DayLocator(interval=10))
plt.xlabel('Date')
plt.ylabel('Number of hospitalizations')
plt.title('Time series of daily hospitalizations')
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)

plt.tight_layout()
plt.savefig('covid19_kurdistan_seir_arima.jpg', dpi=300)
plt.close()
